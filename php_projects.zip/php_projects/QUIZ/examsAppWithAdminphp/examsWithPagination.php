<?php
include_once'dbConnection.php';
include_once'header.php';
 
// PAGINATION CODING START
if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page = 1;
}

// number of pages wishing to display on the browser
$num_per_page = 01;
$start_form = ($page -1) * 01;


// PAGINATION CODING ENDS

// $selectTable = "SELECT * FROM student_table_exams";

// QUERY FOR PAGINATION IN PHP
$query = "SELECT * FROM student_table_exams LIMIT $start_form, $num_per_page";


$result = mysqli_query($dbc, $query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jquery cdn -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- jquery cdn -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.0/css/bulma.min.css">

    <title>Exams App</title>
    <style>
.all1
 {
     background-color:yellow;
     border: blue 2px solid;
      
      
 }
    /*  */
    .container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.container .checkmark:after {
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}

    /*  */

 
   th, td {
  padding: 10px;
  text-align: left;
}

input{
    margin-right:10px; }
}

#option1 {
    color:red;
}
  

    </style>
</head>
<body>

<!-- db -->
<div>
  <h1><strong>Creating Online Quiz Application in PHP</strong> </h1>
 <h3>Using Mysqli Method</h3>
 <hr/>
 </div>
 <?php
if(mysqli_num_rows($result) > 0) {
    ?>
    <table> 
    <?php
    while($row=mysqli_fetch_array($result)){
      // echo $row;
        ?>
       
 <tr> 
 <td><?php echo $row['question_id']  .". ".  $row['questions'] ?> </td>
 </tr> 


  
 <tr> 
 <td><span id='span1' class='radoptions' style='color:red; display:none;'><b> The Correct Answer Is: <?php echo $row['correct_answer']?></b></span></td>
 </tr> 


  
 <div >

 <td class="all1 is-fullwidth">

 <label class="container">
 <input type='radio' id='option1' checked="checked" name="<?php echo $row['question_id']?>" class='radoptions' value="<?php echo $row['option1']?>"/>
  <?php echo $row['option1']?>
   <span class="checkmark"></span>
</label>


 

  <div>
  <label class="container">
  <input type='radio' id='option2' name="<?php echo $row['question_id']?>" class='radoptions' value="<?php echo $row['option2']?>"/>
  <?php echo $row['option2']?> 

  <span class="checkmark"></span>
</label>
  </div>


  <div>
  <label class="container">
  <input type='radio' id='option3' name="<?php echo $row['question_id']?>" class='radoptions' value="<?php echo $row['option3']?>"/>
  <?php echo $row['option3']?> 
  <span class="checkmark"></span>
</label>
  </div>

  <div>
  <label class="container">

  <input type='radio' id='option4' name="<?php echo $row['question_id']?>" class='radoptions' value="<?php echo $row['option4']?>"/>
  <?php echo $row['option4']?> 
  <span class="checkmark"></span>
</label>
   </div>
  </td>
  </div>
 
   
</div>

<?php } ?>
    </table> 
    <?php } ?>



<!-- PAGINARION CONT. -->

<?php
$pr_query = "SELECT * FROM student_table_exams";
$pr_result = mysqli_query($dbc, $pr_query);

// CHECKING THE TOTAL NUMBER OF RECORDS
$total_record = mysqli_num_rows($pr_result);
// echo $total_record;
$total_page = ceil($total_record/$num_per_page);
// echo $total_page;

if($page > 1) {
    echo "<a href='examsWithPagination.php?page=".($page - 1)."' class='button is-danger'>Prev</a>";

}

for($i = 1; $i < $total_page; $i++ ) {
    // echo "<a href='index.php?page=".$i."' class='btn btn-primary'>$i</a>";

}

if($i > $page) {
    echo "<a href='examsWithPagination.php?page=".($page + 1)."' class='button is-danger'>Next</a>";

}

elseif($i = $page) {
    echo "<a href='examsWithPagination.php?page=".($page + 1)."' class='button is-info' id='but1' onclick='displayans()'>Submit</a>";
    echo "<label id='Labmsg'></label>";
}

?>

<!-- PAGINARION CONT. -->

 




<!--  -->
 
<br><br><hr><br><br>
<!--  -->
    
 

<button class="button is-fullwidth is-large is-primary" id="but1" type="button" onclick="displayans()">Submit</button>
<label id="Labmsg"></label>


<script src="index.js"></script>
</body>
</html>