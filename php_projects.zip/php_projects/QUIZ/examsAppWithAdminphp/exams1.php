<?php
include_once'dbConnection.php';
include_once'header.php';
 

$selectTable = "SELECT * FROM student_table_exams";

$result = mysqli_query($dbc, $selectTable);

echo "<center>";
echo "<h1><strong>Creating Online Quiz Application in PHP</strong> </h1>";
echo "<h3>Using Mysqli Method</h3>";
echo"<hr/>";

if(mysqli_num_rows($result) > 0) {
    echo"<table id='customers'>";
    while($row=mysqli_fetch_array($result)){
echo "<tr>";
echo"<td>".$row['question_id'].". ".$row['questions']. "</td>";
echo"</tr>";


echo "<tr>";

 

echo"<td><input type='radio' id='option1' name=".$row['question_id']." class='radoptions' value=".$row['option1']."/>".$row['option1']. "";
echo"<td><input type='radio' id='option2' name=".$row['question_id']." class='radoptions' value=".$row['option2'] ."/>".$row['option2']. "";
echo"<td><input type='radio' id='option3' name=".$row['question_id']." class='radoptions' value=".$row['option3']."/>".$row['option3']. "";
echo"<td><input type='radio' id='option4' name=".$row['question_id']." class='radoptions' value=".$row['option4']."/>".$row['option4']. "";

echo"</td>";
echo"</tr>";

echo"<tr>";
echo"<td><span id='span1' class='radoptions' style='color:red; display:none;'><b> The Correct Answer Is: ".$row['correct_answer']; "</b></span></td>";
echo"</tr>";


    }
    echo"</table>";
}
// echo"</center>";

mysqli_close($dbc);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jquery cdn -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- jquery cdn -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.0/css/bulma.min.css">

    <title>Exams App</title>



    <style>
    th, td {
  padding: 10px;
  text-align: left;
}

input{
    margin-right:10px; }
}

  

    </style>
</head>
<body>
    
 

<button class="button is-large is-primary" id="but1" type="button" onclick="displayans()">Submit</button>
<label id="Labmsg"></label>


<script src="index.js"></script>
</body>
</html>