## Simple PHP app

This exams app allow admin to add new Exams to database as well as perform all CRUD operation on all Questions and answers.

Exans takers can easily assess exams without login operations.