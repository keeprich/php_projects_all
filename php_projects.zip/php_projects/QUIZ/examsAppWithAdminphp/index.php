<?php
include_once'header.php';
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Exams</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.0/css/bulma.min.css">
  </head>
  <body>

<style>
.back_img {
  background-color:red;
  height:480px;
}

#myVideo {
  /* position: fixed; */
  right: 0;
  bottom: 0;
  min-width: 100%; 
  min-height: 50px;
}

/* .content {
  position: fixed;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
} */
</style>


<!--  -->
<!-- https://player.vimeo.com/external/389724688.sd.mp4?s=f2a03fab852850c79d37fed83bc40caeded323c3&profile_id=164 -->
<!--  -->

<div class="container content">
      <h1 class="title">
        World Class Online Exams
      </h1>
      <p class="subtitle">
        My first website with <strong>Keeprich</strong>!
      </p>
       
    </div>
  <section class="section back_im">
  <video autoplay muted loop id="myVideo">
  <source src="https://player.vimeo.com/external/389724688.sd.mp4?s=f2a03fab852850c79d37fed83bc40caeded323c3&profile_id=164" type="video/mp4">
  Your browser does not support HTML5 video.
 </video> 


    
     <a href="exams1.php">Example exams</a><br>
     <a href="paginate.php">Exams pagination</a><br>
     <a href="examsWithPagination.php">Exams With pagination</a>


  </section>
  </body>
</html>