<?php
include_once'dbConnection.php';
include_once'codeLogic.php';

include_once'header.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
<html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.0/css/bulma.min.css">
 
<style>
.llaauu {
    margin-left {
        30px;
    }
}
</style>


</head>
<body >
<div style="width:100%;text-align:center">
<h1> Student Detail System</h1>
</div>
<div style="width:100%; align:center;">
<form action="viewDetails.php" method="post" class="form" enctype="multipart/form-data">



<div class="field  ">
<div class="control container is-fluid ">
<strong>Question  :</strong>
 <input class="input is-medium llaauu"  name="questions" type="text" value="<?php echo (isset($question))?$question:'';?>">
 </div>
 </div>

<div class="control container is-fluid"><strong> Option1 : </strong><input class="input is-large"  name="option1" type="text" value="<?php echo (isset($option1))? $option1:'';?>"></div>
<div class="control container is-fluid"><strong> Option2 : </strong><input class="input is-large"  name="option2" type="text" value="<?php echo (isset( $option2))? $option2:'';?>"></div>

<div class="control container is-fluid"><strong> Option3 : </strong><input class="input is-large"  name="option3" type="text" value="<?php echo (isset( $option3))? $option3:'';?>"></div>
<div class="control container is-fluid"><strong> Option4 : </strong><input class="input is-large"  name="option4" type="text" value="<?php echo (isset( $option4))? $option4:'';?>"></div>
<div class="control container is-fluid"><strong> Correct Answer : </strong><input class="input is-large"  name="correct_answer" type="text" value="<?php echo (isset($correct_answer))?$correct_answer:'';?>"></div>

<div style="margin:10px;" ><input  name="question_id" style="display:none;" type="text" value="<?php echo (isset($question_id))?$question_id:'';?>"></div>
</div>
<br><br> 

<div   class=" container is-fluid">

<input  name="submit"  class="button is-success is-outlined" type="submit" value="Insert"/>
<input  name="Update" class="button is-primary is-outlined" type="submit" value="Update"/>
<input  name="Delete" class="button is-danger is-outlined" type="submit" value="Delete"/>
</div>
</form>
<br><br><br>
</body>

</html>