<?php
$dbc=mysqli_connect("localhost","keeprich","keeprich","all_php_projects");

if (!$dbc) {
    die("Connection failed: " . mysqli_connect_error());
  }
//   echo "Connected successfully";
  ?>
