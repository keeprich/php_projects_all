# Online Examination System In PHP

This is a Online Examination System In PHP , created by Mahmudul Hassan with the massive support and involvement of the community.

## Installation

Download the zip file, then extract it to your localhost..

## Usage

```python
import Database
siteurl/admin
username: admin
password: 123
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
This project is released under the [MIT](https://choosealicense.com/licenses/mit/) license.
