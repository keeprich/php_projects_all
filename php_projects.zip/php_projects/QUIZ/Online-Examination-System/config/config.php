<?php
define("DB_HOST", "localhost");
define("DB_USER", "keeprich");
define("DB_PASS", "keeprich");
define("DB_NAME", "db_exam");
?>