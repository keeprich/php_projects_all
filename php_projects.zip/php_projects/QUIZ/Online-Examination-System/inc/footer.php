 </section>
<section class="footeroption">
		<h2>
			<span>Copyright &copy;</span>
			<script type="text/javascript">
				var d = new Date();
				document.write(d.getFullYear());
			</script>
			<span>
				<a target="_blank" href="https://www.facebook.com/promahmudul">
					ProMahmudul
				</a>
			</span>
		</h2>
	</section>
</div>
</body>
</html>