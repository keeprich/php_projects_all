<?php 
/*
	$filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/classes/User.php');
	$userid  = Session::get("userid");
	$usr = new User();

	$name 		= $_POST['name'];
	$username 	= $_POST['username'];
	$email 		= $_POST['email'];
	$updateUser 	= $usr->updateUserData($userid, $name, $username, $email);
*/
?>