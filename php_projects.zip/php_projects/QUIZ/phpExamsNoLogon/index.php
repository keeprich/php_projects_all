<?php

include_once'dbConnection.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jquery cdn -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- jquery cdn -->
    <title>Document</title>
</head>
<body>
    


<!-- <button onclick="myFunction()">Click me</button>

<p id="demo"></p> -->

<button id="but1" type="button" onclick="displayans()">Submit</button>
<label id="Labmsg"></label>





    <script src="index.js"></script>

</body>
</html>