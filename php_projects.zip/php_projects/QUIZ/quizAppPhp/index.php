<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Rokkitt|Yeseva+One" rel="stylesheet">
    <link rel="stylesheet" href="index.css">
    <title>Quiz App</title>
</head>
<body>
 
    <div class="front">
        <h1>HTML and CSS Quiz</h1>
        <button type="button" id="start">Start</button>    
    </div>
    <div class="quiz">
        <p id="num"></p>
        <div id="q"></div><div class="arrow"></div><br>
        <div class="radio">
            <div id="op1"></div>
            <div id="op2"></div>
            <div id="op3"></div>
            <div id="op4"></div>
        </div><br>
        <center><button type="button" id="sub">Submit</button></center>
    </div>
    <div class="result" >
        <div class="score"></div>
        <br>
        <div class="message"></div>
        <button type="button" id="an">Click here to see answers</button>
    </div>
    <div class="answers">
        <p class="qa">1.Which tag is used to create clickable link?</p>
        <p >Ans:<span id="a1">&lt;a&gt;</span></p>
        <p class="qa">2.Which tag is used to specify a list of prefined options for input controls?</p>
        <p >Ans:<span id="a2">&lt;datalist&gt;</p>
        <p class="qa">3. Which HTML element is used to display a scalar measurement within a range?</p>
        <p >Ans:<span id="a3">&lt;meter&gt;</span></p>
        <p class="qa">4.Choose the correct HTML element to define important text?</p>
        <p >Ans:<span id="a4">&lt;strong&gt;</span></p>
        <p class="qa">5.______ element in HTML5 is used to indicate that text has been added to the document.?</p>
        <p>Ans:<span id="a5">&lt;ins&gt;</span></p>
        <p class="qa">6.______ attribute used in &lt;table&gt; element sets the width, in pixels, between the edge of a cell and its content</p>
        <p>Ans:<span id="a6">cellpadding</span></p>
        <p class="qa">7.Which attribute specifies the stack order of an element?</p>
        <p >Ans:<span id="a7">z-index</span></p>
        <p class="qa">8.Which property controls scrolling of an image in background? </p>
        <p >Ans:<span id="a8">background-attachment.</span></p>
        <p class="qa">9.What is default value of position property?</p>
        <p >Ans:<span id="a9">static</span></p>

        <p class="qa">10.Which CSS has highest priority?</p>
        <p>Ans:<span id="a10">inline</p>
    </div>
    
 <script src="index.js"></script>
</body>
</html>
