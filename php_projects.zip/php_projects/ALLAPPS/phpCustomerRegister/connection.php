<?php 
$con = mysqli_connect('localhost', 'keeprich', 'keeprich', 'customerRegister');


if(!$con) 
{
    die("connection error");
}
?>