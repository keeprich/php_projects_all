<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


    <title>Customer Register</title>
</head>
<body class="bg-dark">
    
<!-- <div class="container text-center">
<h1>Customer Register</h1>
</div> -->

<div class="container">
  <div class="row">
    <div class="col-lg-6 m-auto">
      <div class="card mt-5">
      <div class="card-title">
      <h3 class="bg-success text-white text-center py-3">Registration form</h3>

      <div class="card-body">
      <form action="insert.php" method="post">
      
      <input type="text" name="name" class="form-control mb-2" placeholder="name" id="">
      <input type="email" name="email" class="form-control mb-2" placeholder="User email" id="">
      <input type="text" name="age" class="form-control mb-2" placeholder="User age" id="">

<button name="submit" class="btn btn-primary">Submit</button>
      </form>
      </div>
      </div>
      </div>
    </div>
    
     
  </div>
</div>

<br><br>

<a href="view.php">
    <button class="btn btn-primary btn-lg btn-block">View Records</button>
    </a>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>