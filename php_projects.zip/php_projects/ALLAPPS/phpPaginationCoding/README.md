##PHP PAGINATION USING DATABASE

a simple php and mysql database app, including pagination