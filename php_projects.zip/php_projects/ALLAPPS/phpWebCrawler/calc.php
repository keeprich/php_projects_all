<?php

system("calc");
echo 'hi'

?>